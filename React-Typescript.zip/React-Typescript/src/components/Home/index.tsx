const HomePage = () =>{
    return(
        <>
            <h1>Головна сторінка</h1>
            
        </>
    )
}


export default HomePage;